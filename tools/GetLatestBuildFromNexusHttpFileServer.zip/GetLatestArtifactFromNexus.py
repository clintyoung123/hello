#!/usr/bin/env python3
"""LMAN latest build checking utility.
it get latest build and download artifact from nexus (eg apk or jar)
=== Usage:
    Example: %prog -a lync -e .apk -f https://nexus.skype.net/content/repositories/skype/skype/lync/android/release/
    Example: %prog -a LyncTest -e .jar -f https://nexus.skype.net/content/repositories/skype/skype/lync/android/testautomation
=== Dependency
  This script uses python3 and following 2 packages
    1. beautiful soup 4
    2. requests

 install reference for Mac
    (which python3) cd /usr/local/bin 
    - easy_install-3.4 BeautifulSoup4
    - easy_install-3.4 requests
"""

import os
import sys
import re
import datetime
import requests
from bs4 import BeautifulSoup
from bs4 import Tag
from optparse import OptionParser


# ==========================================================
class BuildInfo:
    """ Test build infomation class"""
    def __init__(self):
        self.version = ""
        self.url = ""
        self.config = ""
        self.timestamp = datetime.datetime.min        
    def get(self):
        return (self.version, self.url, self.config, self.timestamp)
    def StdConvertedFormat(self):
        return str.format("%s %s %s %s" %(self.version,self.config,self.timestamp, self.url))

# ===========================================================
def main():
    # Default arguments
    defaultLyncReleaseRUL="https://nexus.skype.net/content/repositories/skype/skype/lync/android/release"
    defaultArtifact="lync"
    defaultExt=".apk"
    defaultUserName = "lmanauto"
    defaultPassword = "#######"

    maxSearchNumber=10
    
    # Parse option and arguments
    parser = OptionParser(usage="usage: %prog [options] arg", version="%prog 1.1",
                          description="Example: %prog -a lync -e .apk -f https://nexus.skype.net/content/repositories/skype/skype/lync/android/release")
    parser.add_option('-a', '--artifact', dest='artifact', default=defaultArtifact,
                    type='string', help='the config or flavor to check for artifact.')
    parser.add_option('-e', '--ext', dest='ext', default=defaultExt,
                    type='string', help='the config or flavor to check for artifact.')
    parser.add_option('-f', '--url', dest='releaseUrl', default=defaultLyncReleaseRUL,
                    type='string', help='release url on nexus for this artifact')
    parser.add_option('-u', '--user', dest='user', default=defaultUserName,
                    type='string', help='user name MS AD')
    parser.add_option('-p', '--pass', dest='password', default=defaultPassword,
                    type='string', help='password')
    
    (options, args) = parser.parse_args()
    if len(args) > 0:
        parser.error("incorrect number of arguments")
    print ("artifact= %s" % options.artifact)
    print ("ext= %s" % options.ext)
    print ("releaseUrl= %s" % options.releaseUrl)
    print ("user= %s" % options.user)
    print ("pass= %s" % options.password)

    artifact=options.artifact
    ext = options.ext
    defaultLocalArtifactFileName=artifact+ext
 
    # Parse URL to get current build list
    username = options.user
    password = options.password
    url = options.releaseUrl

    print ("requesting... from %s" % url)
    r = requests.get(url, auth=(username, password))  
    print (["statuscode: ",r.status_code])

    soup = BeautifulSoup(r.text)
    soup.prettify()
    builds = []
    for anchor in soup.findAll('a', href=True):
        build = BuildInfo()
        if (anchor.string) and ("Parent Directory" in anchor.string):
            continue
        build.version = anchor.string.strip(' /')
        build.url = anchor['href']
        builds.append(build)

    for b in builds:
        print([b.version, b.url])
        
    print("---- total builds: %d ----" % len(builds))

    # Get latest one build
    reversedBuilds = builds[::-1]
    latestVersion = ""
    latestArtifactUrl = ""
    latestArtifactName = ""
    flavor=""
    counter = 0
    for b in reversedBuilds:
        flavor = getBuildConfigName(b.url, username, password )
        [artifactUrl, artifactName] = getArtifactUrlWithExt(b.url, username, password, ext)
        print ([b.version, flavor, artifactName, artifactUrl])
        if len (artifactUrl) > 0:
            print (" ---- found build %s %s---- " % (flavor, b.version))
            latestArtifactName = artifactName
            latestArtifactUrl = artifactUrl
            latestVersion = b.version
            break        
        if counter > maxSearchNumber:
            print (" ---- break on maximum search effort %d---- " % counter+1)
            break
        counter += 1

    # Record Latest Build info and download if found
    if len(latestArtifactUrl) > 0:
        print ([latestVersion, flavor, latestArtifactName, latestArtifactUrl])
       
        with open(options.artifact+"_latestBuildInfo.txt", 'w') as f:
            f.write(latestVersion+"\n")
            f.write(latestArtifactUrl+"\n")
            f.write(latestArtifactName+"\n")        
        download_file(latestArtifactUrl, defaultLocalArtifactFileName, username, password)
    else:
        print ("!---- latest build artifact not found with flavor %s" % flavor)
            
def getBuildConfigName(url, username, password):
    flavor = ""

    ivyUrl=url+"ivy.xml"
    r = requests.get(ivyUrl, auth=(username, password))  
    print (["request ivy.xml:", ivyUrl])
    print (["statuscode: ",r.status_code])
    
    soup = BeautifulSoup(r.text)
    soup.prettify()
    for config in soup.findAll('conf'):
        flavor = config["name"]
        print (config)
    return flavor

def getArtifactUrlWithExt(url, username, password, ext):
    artifactUrl = ""
    artifactName = ""
    
    r = requests.get(url, auth=(username, password))  
    print (["request build repository URL", url])
    print (["statuscode: ",r.status_code])
    
    soup = BeautifulSoup(r.text)
    soup.prettify()
    for a in soup.findAll('a'):
        if (a.string) and (a.string.endswith(ext)):
            artifactName = a.string
            artifactUrl = a["href"]
    return [artifactUrl, artifactName]

def download_file(url, local_filename, username, password):
    if local_filename=="":
        local_filename = url.split('/')[-1]
    print ("-- downloading file as %s from %s" % (local_filename, url))
    # NOTE the stream=True parameter
    chunkCount=0
    r = requests.get(url, stream=True, auth=(username, password))
    with open(local_filename, 'wb') as f:
        for chunk in r.iter_content(chunk_size=1024):
            chunkCount += 1
            if chunkCount % 1024 == 0:
                sys.stdout.write( '.' )   # progressing .
                sys.stdout.flush()
            if chunk: # filter out keep-alive new chunks
                f.write(chunk)
                f.flush()
    return local_filename

# ==========================================================
if __name__ == "__main__":
	main()

