#!/bin/bash
# ------------------------------------------------------------------
# [qingy] script to download build from nexus server directly without using SkypeAnt
# ------------------------------------------------------------------
echo "==============================================================="
echo "------ Begin: GetLatestLyncBuild.sh [Timestamp: $(date)]------ "
echo "."

# --- Parameters --------------------------------------------------
config_flavor=$1
if [ "x$config_flavor"=="x" ]; then
    config_flavor=release
fi
echo "config_flavor is $config_flavor"

# --- Parameters from Environment Variable--------------------------
if [ "x$LMAN_Username" == "x" ]; then
    #export LMAN_Username=lmanauto
    echo "[!]Environment Variable LMAN_Username not set"
    read -p "Enter user name MS AD: " LMAN_Username
fi
if [ "x$LMAN_Userpass" == "x" ]; then
    #export LMAN_Userpass=LyncPass#######
    echo "[!]Environment Variable LMAN_Userpass not set, set it in .bash_profile for convenience"
    read -s -p "Enter Password: " LMAN_Userpass
fi
echo "LMAN_Username is $LMAN_Username"
#echo "LMAN_Userpass is $LMAN_Userpass"

# --- const configuration--------------------------------------------
nexus_build_base_url=https://nexus.skype.net/content/repositories/skype/skype/lync/android
    
# --- Downloading & copy to apk, jar folders ------------------------
# python3 GetLatestArtifactFromNexus.py -a lync -e .apk -f https://nexus.skype.net/content/repositories/skype/skype/lync/android/release/
# python3 GetLatestArtifactFromNexus.py -a LyncTest -e .jar -f https://nexus.skype.net/content/repositories/skype/skype/lync/android/testautomation

echo "."
echo "--- download latest lync.apk from nexus -----"
    rm lync.apk
	artifact_nexus_url="${nexus_build_base_url}/${config_flavor}"
	artifactNameLocal="lync"
	artifactExt=".apk"
	python3 GetLatestArtifactFromNexus.py -a ${artifactNameLocal} -e $artifactExt -f $artifact_nexus_url -u $LMAN_Username -p $LMAN_Userpass
    
    echo "--- copy downloaded $(pwd)/lync.apk --> $(pwd)/../apk/app-${config_flavor}.apk"
    if [ ! -d "../apk" ]; then
        mkdir "../apk"
    fi
    rm ../app/app-${config_flavor}.apk
    cp lync.apk ../apk/app-${config_flavor}.apk

echo "."
echo "--- download latest lyncTest.jar from nexus -----"
    rm LyncTest.jar
    test_artifact_nexus_url="${nexus_build_base_url}/testautomation"
    test_artifactNameLocal="LyncTest"
    test_artifactExt=".jar"
    python3 GetLatestArtifactFromNexus.py -a $test_artifactNameLocal -e $test_artifactExt -f $test_artifact_nexus_url -u $LMAN_Username -p $LMAN_Userpass
    echo "-- copy downloaded $(pwd)/LyncTest.jar --> $(pwd)/../jar/LyncTestAutomation.jar"
    if [ ! -d "../jar" ]; then
        mkdir "../jar"
    fi
    rm ../jar/LyncTestAutomation.jar
    cp LyncTest.jar ../jar/LyncTestAutomation.jar

echo "."
echo "------ Exit: GetLatestLyncBuild.sh [Timestamp: $(date)]------ "
echo "==============================================================="
